package com.corrot.tcp_test

import android.os.Bundle
import android.util.Log
import android.view.View
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.Observer
import androidx.lifecycle.ViewModelProviders
import kotlinx.android.synthetic.main.activity_main.*

class MainActivity : AppCompatActivity() {
    companion object {
        const val TAG = "mainActivity"
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val mainViewModel = ViewModelProviders.of(this).get(MainViewModel::class.java)
        mainViewModel.isConnected().observe(this, Observer {
            Log.d(TAG, "Connection status changed: $it")
            when (it) {
                true -> {
                    pb_main.visibility = View.GONE
                    v_shadow.visibility = View.GONE
                }
                false -> {
                    pb_main.visibility = View.VISIBLE
                    v_shadow.visibility = View.VISIBLE
                }
            }
        })

        mainViewModel.getInputData().observe(this, Observer {
            tv_input_data.text = it
        })

        btn_send.setOnClickListener {
            mainViewModel.generateMsg()
        }
    }
}
