package com.corrot.tcp_test

import android.os.NetworkOnMainThreadException
import android.util.Log
import com.corrot.tcp_test.Constants.Companion.IP
import com.corrot.tcp_test.Constants.Companion.PORT
import java.io.IOException
import java.io.InputStream
import java.io.PrintWriter
import java.net.InetSocketAddress
import java.net.Socket
import java.net.SocketTimeoutException
import java.net.UnknownHostException
import kotlin.concurrent.thread

/**
 * Singleton socket repository for handling low level stuff.
 */
object SocketRepository {
    private const val TAG = "SocketRepository"

    interface InputListener {
        fun onDataLoaded(data: String)
        fun onConnectionChange(isConnected: Boolean)
    }

    private var listener: InputListener? = null

    private lateinit var taskerThread: Thread
    private lateinit var looperThread: LooperThread

    private lateinit var socket: Socket
    private lateinit var writer: PrintWriter
    private lateinit var inputStream: InputStream

    private var connected: Boolean = false
    private var connecting: Boolean = false
    var msg: String = "[000000]"

    init {
        thread(start = true) {
            run {
                connect()
            }
        }
    }

    /**
     * Function that connects TCP socket, starts looperThread and taskerThread
     */
    private fun connect() {
        connecting = true
        setConnectedStatus(false)
        Log.d(TAG, "Instantiating SocketRepository...")
        try {
            Log.d(TAG, "Connecting to: $IP")

            socket = Socket()
            socket.connect(InetSocketAddress(IP, PORT), 3000)
            writer = PrintWriter(socket.getOutputStream())
            inputStream = socket.getInputStream()

            if (socket.isConnected) {
                setConnectedStatus(true)
                Log.d(TAG, "SocketRepository created successfully!")

                // Start looper thread
                looperThread = LooperThread()
                looperThread.start()

                // Start tasking thread
                taskerThread = thread(start = true) { startTasking() }
            } else {
                Log.e(TAG, "SocketRepository creating failed!")
            }
        } catch (e: Exception) {
            when (e) {
                is IOException ->
                    Log.e(TAG, e.message.toString())
                is UnknownHostException ->
                    Log.e(TAG, e.message.toString())
                is NetworkOnMainThreadException ->
                    Log.e(TAG, "You can't connect TCP on main thread!")
                is SocketTimeoutException ->
                    Log.e(TAG, "TIMEOUTTTTTTTTTTTT")
                else ->
                    Log.e(TAG, e.toString())
            }

            setConnectedStatus(false)
        }
    }

    fun registerListener(listener: InputListener) {
        this.listener = listener
    }

    private fun setConnectedStatus(isConnected: Boolean) {
        connected = isConnected
        connecting = false
        listener?.onConnectionChange(connected)
        Log.d(TAG, "Connection status changed: $connected")
    }

    /**
     * Function that posts runnables to looperThread handler every _ millis
     */
    private fun startTasking() {
        Log.d(TAG, "Starting writing...")
        while (true) {
            // Check connection
            val checkConnectionRunnable = Runnable {
                val connectionStatus = !writer.checkError()
                if (connected != connectionStatus)
                    setConnectedStatus(connectionStatus)
            }
            looperThread.mHandler?.post(checkConnectionRunnable)

            if (connected) {
                // Write motors value
                val writeRunnable = WriteRunnable(writer, msg)
                looperThread.mHandler?.post(writeRunnable)

                // Read input
                val readRunnable = ReadRunnable(inputStream, listener)
                looperThread.mHandler?.post(readRunnable)
            } else {
                if (!connecting) {
                    thread(start = true) {
                        run {
                            connect()
                        }
                    }
                }
            }

            Thread.sleep(Constants.SAMPLE_TIME)
        }
    }
}
