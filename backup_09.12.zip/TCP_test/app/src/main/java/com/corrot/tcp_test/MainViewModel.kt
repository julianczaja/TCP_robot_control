package com.corrot.tcp_test

import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import java.util.*

class MainViewModel : ViewModel() {

    private val socketRepository = SocketRepository

    private var connected = MutableLiveData<Boolean>()
    private var inputData = MutableLiveData<String>()

    init {
        socketRepository.registerListener(object : SocketRepository.InputListener {
            override fun onDataLoaded(data: String) {
                inputData.postValue(data)
                // TODO: convert data 
            }

            override fun onConnectionChange(isConnected: Boolean) {
                connected.postValue(isConnected)
            }
        })
    }

    fun isConnected(): LiveData<Boolean> {
        return connected
    }

    fun getInputData(): LiveData<String> {
        return inputData
    }

    fun generateMsg() {
        var m = "["
        for (i in 1..6) {
            m += Random().nextInt(9).toString()
        }
        m += "]"
        socketRepository.msg = m
    }
}
