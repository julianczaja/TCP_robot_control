package com.corrot.tcp_test

import androidx.lifecycle.MutableLiveData

/**
 * Helps to notify observer after setting MutableLiveData value
 * https://stackoverflow.com/a/52075248/10559761
 */
fun <T> MutableLiveData<T>.notifyObserver() {
    this.value = this.value
}
