package com.corrot.tcp_test

class Constants {
    companion object {
        const val IP = "192.168.137.1"
        const val PORT = 8000
        const val SAMPLE_TIME = 500L
        const val OUTPUT_FRAME_SIZE = 8
        const val INPUT_FRAME_SIZE = 30
    }
}